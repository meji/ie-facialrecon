# IE Facial Recognition layouts
HTML, SCSS, Bootstrap
